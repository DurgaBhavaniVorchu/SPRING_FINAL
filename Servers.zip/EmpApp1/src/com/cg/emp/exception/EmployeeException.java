package com.cg.emp.exception;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
	}

	public EmployeeException(String msg) {
		super(msg);
	}
}
