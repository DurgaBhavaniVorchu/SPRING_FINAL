package com.cg.emp.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Employee {
	@Id
	private int id;
	@NotEmpty(message = "Name is Mandatory")
	@Pattern(regexp ="[A-Z][A-Za-z]{2,}",message = "Name should start with Capital letter")
	private String name;
	@Pattern(regexp = "(Male|Female)", message = "Gender must be Male or Female")
	private String gender;
	@Min(value = 18, message="Minimum age should be 18")
	@Max(value = 60, message="Maximum age should be 60")
	private int age;
	private double salary;

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}