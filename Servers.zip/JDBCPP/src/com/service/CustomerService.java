package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.bean.Customer;
import com.bean.Transaction;
import com.dao.CustomerDao;
import com.exception.BankException;

public class CustomerService implements ICustomerService {
	CustomerDao bankDao = new CustomerDao();
	@Override
	public void createTransaction(Transaction transaction) {
		bankDao.createTransaction(transaction);
		
	}

	@Override
	public void createAccount(Customer customer) {
		bankDao.createAccount(customer);
		
	}

	@Override
	public Customer showBalance(long accNo) {
		return bankDao.showBalance(accNo);
	}

	@Override
	public Customer deposit(long accno, int amount) {
		Customer cust=bankDao.deposit(accno);
		float initialBalance = cust.getBalance();
		float finalBalance = initialBalance + amount;
		cust.setBalance(finalBalance);
		
		return cust;
	}

	@Override
	public Customer withdraw(long accno, int amount) {
		Customer cust=bankDao.withdraw(accno);
		float initialBalance = cust.getBalance();
		float finalBalance = initialBalance - amount;
		cust.setBalance(finalBalance);
		
		return cust;
	}

	@Override
	public Customer fundTransfer(long sourceAccNo, long destinationAccNo, int tfamount) {
		Customer sourceCust=bankDao.SourcefundTransfer(sourceAccNo);
		Customer DestiCust=bankDao.DestinationfundTransfer(destinationAccNo);
		float SourceinitialBalance = sourceCust.getBalance();
		float DestinationinitialBalance = DestiCust.getBalance();
		float sourceFinalbal = SourceinitialBalance - tfamount;
		float destinationFinalbal = DestinationinitialBalance + tfamount;
		sourceCust.setBalance(sourceFinalbal);
		DestiCust.setBalance(destinationFinalbal);
		return sourceCust;
	}

	@Override
	public List<Transaction> printTransactions(long accn) {
		
		return bankDao.printTransaction(accn);
	}
	public boolean isNameValid(String name) {
		if(name.length()>4){
	          if(Pattern.matches("[A-Z]([a-z])*", name)){
	        return true;
	          }else {
	        	  try {
	              	throw new BankException("Name Should Start with capital Letter and continue with small letters");
	              }catch(BankException ex) {
	              	System.out.println(ex);
	              	return false;
	              }
	     }}
	     else
	       {
	    	  try {
	            	throw new BankException("Name length should be minimum 5");
	            }catch(BankException ex) {
	            	System.out.println(ex);
	            	return false;
	            }
	    }
	}

	public boolean isPhoneNumberValid(String Phonenumber) {
		if (Phonenumber.matches("^[6-9][0-9]{9}$")) {
			return true;
		} else {
			try {
				throw new BankException("PhoneNumber is not Valid");
			} catch (BankException ex) {
				System.out.println(ex.getMessage());
				return false;
			}
		}
	}

	public boolean isAadharNumberValid(String Aadharnumber) {
		if (Aadharnumber.matches("^[0-9][0-9]{11}$")) {
			return true;
		} else {
			try {
				throw new BankException("AadharNumber is not Valid");
			} catch (BankException ex) {
				System.out.println(ex);
				return false;
			}
		}
	}

	public boolean isAccountValid(long accountNo){
		Customer customer=bankDao.showBalance(accountNo);
		if(customer.getAccountNo()==accountNo) {
			return true;
		}
		else {
			try {
				throw new BankException("Account Number not found");
			} catch (BankException ex) {
				System.out.println(ex);
				return false;
			}
		}
}
}
