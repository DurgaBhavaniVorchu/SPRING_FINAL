package com.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.bean.Customer;
import com.bean.Transaction;

public interface ICustomerService {
	public void createTransaction(Transaction transaction);
public void createAccount(Customer customer);
public Customer showBalance(long accNo);
public Customer deposit(long accno, int amount);
public Customer withdraw(long accno, int amount);
public Customer fundTransfer(long sourceAccNo, long destinationAccNo, int tfamount);
public List<Transaction> printTransactions(long accn);

}
