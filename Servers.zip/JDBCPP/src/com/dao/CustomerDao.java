package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.bean.Customer;
import com.bean.Transaction;

/*create table BankCustomer (accNo number(10),Username varchar2(50),PhoneNo varchar2(50),AadharNo varchar2(50),Balance number(20));
create table TransactionCustomer (transID number(10),transType varchar2(50),accNo number(10),Amount number(20));

select*from BankCustomer;
select*from TransactionCustomer;*/
public class CustomerDao implements ICustomerDao {
	Connection conn;

	public CustomerDao() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@Localhost:1521:xe", "INVENTORY1", "INVENTORY1");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();

		}
	}

	@Override
	public void createAccount(Customer customer) {
		try {
			PreparedStatement p = conn.prepareStatement("insert into BankCustomer values(?,?,?,?,?)");
			p.setLong(3, customer.getAccountNo());
			p.setString(1, customer.getFullName());
			p.setString(2, customer.getPhoneNo());
			p.setString(5, customer.getAadharNo());
			p.setFloat(4, customer.getBalance());

			p.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		
	}

	@Override
	public Customer showBalance(long accNo) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accNo=" + accNo);
			while (rs.next()) {
				long accno = rs.getLong(1);
				float bal = rs.getFloat(5);
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;
	}

	@Override
	public Customer deposit(long accno) {
		
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accNo=" + accno);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5);
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;
	}

	@Override
	public Customer withdraw(long accno) {
		Customer cust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accNo=" + accno);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5);
				cust.setAccountNo(accno);
				cust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;
	}

	@Override
	public Customer SourcefundTransfer(long sourceAccNo) {
		Customer Sourcecust = new Customer();
		
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accNo=" + sourceAccNo);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5);
				Sourcecust.setAccountNo(accNo);
				Sourcecust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		
		return Sourcecust;
	}

	@Override
	public Customer DestinationfundTransfer(long destinationAccNo) {
		Customer Desticust = new Customer();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankCustomer where accNo=" + destinationAccNo);
			while (rs.next()) {
				long accNo = rs.getInt(1);
				float bal = rs.getFloat(5);
				Desticust.setAccountNo(accNo);
				Desticust.setBalance(bal);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return Desticust;
	}

	@Override
	public List<Transaction> printTransaction(long accn) {
		List<Transaction> list=new ArrayList<Transaction>();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from TransactionCustomer where accNo=" + accn);
			while (rs.next()) {
				Transaction transaction=new Transaction();
				long accno = rs.getInt(3);
				float amount = rs.getFloat(4);
				String type=rs.getString(2);
				int transId=rs.getInt(1);
				transaction.setAccountNumber(accno);
				transaction.setAmount(amount);
				transaction.setTransactionType(type);
				transaction.setTransactionId(transId);
				list.add(transaction);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return list;
	}

	@Override
	public void createTransaction(Transaction transaction) {
		try {
			PreparedStatement p = conn.prepareStatement("insert into TransactionCustomer values(?,?,?,?)");
			p.setLong(1,transaction.getTransactionId());
			p.setString(2, transaction.getTransactionType());
			p.setLong(3,transaction.getAccountNumber());
			p.setFloat(4,transaction.getAmount());

			p.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		
	}

	

}
