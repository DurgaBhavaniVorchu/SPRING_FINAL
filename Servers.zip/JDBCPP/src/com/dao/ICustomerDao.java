package com.dao;

import java.util.HashMap;
import java.util.List;

import com.bean.Customer;
import com.bean.Transaction;

public interface ICustomerDao {
	public void createTransaction(Transaction transaction);
	public void createAccount(Customer customer);
	public Customer showBalance(long accNo);
	public Customer deposit(long accno);
	public Customer withdraw(long accno);
	public Customer SourcefundTransfer(long sourceAccNo);
	public Customer DestinationfundTransfer(long destinationAccNo);
	public List<Transaction> printTransaction(long accn);

}
