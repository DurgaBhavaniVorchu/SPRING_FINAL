package com.test;

import java.sql.SQLException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.bean.Customer;
import com.dao.CustomerDao;

public class CustomerDaoTest {
	CustomerDao dao;

	@Before
	public void CustomerMethod() {
		dao = new CustomerDao();
	}

	@Test
	public void TestGetAccountDetails() throws SQLException {
		Customer accountDetails = dao.showBalance(Long.valueOf(655849335));
		Long actual = accountDetails.getAccountNo();
		Long expected = Long.valueOf(655849335);
		Assert.assertEquals(expected, actual);
	}

	@Test
	public void TestwithdrawBalance() throws SQLException {
		Customer accountDetails = dao.showBalance(Long.valueOf(655849335));
		float actual = accountDetails.getBalance();
		actual = actual - 100;
		float expected = 400;
		Assert.assertEquals(expected, actual, 0);
	}

	@Test
	public void TestdepositeBalance() throws SQLException {
		Customer accountDetails = dao.showBalance(Long.valueOf(655849335));

		float actual = accountDetails.getBalance();
		actual = actual + 100;

		int expected = 600;
		Assert.assertEquals(expected, actual, 0);
	}

}
