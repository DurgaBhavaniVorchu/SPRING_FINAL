package com.bean;

public class Transaction {
	private int transactionId;
	private String transactionType;
	private long AccountNumber;
	private float amount;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public long getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		AccountNumber = accountNumber;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", AccountNumber=" + AccountNumber + ", amount=" + amount + "";
	}
	public Transaction(int transactionId, String transactionType, long accountNumber, float amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		AccountNumber = accountNumber;
		this.amount = amount;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
