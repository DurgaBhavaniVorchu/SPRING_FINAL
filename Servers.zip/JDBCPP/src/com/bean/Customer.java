package com.bean;

public class Customer {
private String FullName;
private String phoneNo;
private long accountNo;
private float balance;
private String aadharNo;

public String getFullName() {
	return FullName;
}
public void setFullName(String fullName) {
	FullName = fullName;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
public String getAadharNo() {
	return aadharNo;
}
public void setAadharNo(String aadharNo) {
	this.aadharNo = aadharNo;
}
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String name, String phoneNo, long accountNo, float balance, String aadharNo) {
	super();
	this.FullName = name;
	this.phoneNo = phoneNo;
	this.accountNo = accountNo;
	this.balance = balance;
	this.aadharNo = aadharNo;

}
@Override
public String toString() {
	return "name=" + FullName + ""
		+ " phoneNo=" + phoneNo + ","
		+ " accountNo=" + accountNo + ","
		+ " balance=" + balance+ ","
		+ " aadharNo=" + aadharNo + ",";
}

}
