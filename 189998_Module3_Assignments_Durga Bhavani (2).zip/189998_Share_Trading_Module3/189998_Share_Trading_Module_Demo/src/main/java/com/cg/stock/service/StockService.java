package com.cg.stock.service;

import java.util.List;
import com.cg.stock.bean.Stock;
import com.cg.stock.exception.StockException;

//inteface of service class which contains method declaration
public interface StockService {
	List<Stock> addStock(Stock stock) throws StockException;

	List<Stock> updateStock(Stock stock) throws StockException;

	List<Stock> getAllStocks() throws StockException;

	List<Stock> deleteStock(int id) throws StockException;

	Stock getStockById(int id) throws StockException;
}
