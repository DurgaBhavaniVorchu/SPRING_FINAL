package com.cg.stock.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

//Pojo class is implementing
@Entity
public class Stock {
	// primary key is id
	@Id
	// random value for id
	@SequenceGenerator(name = "seq", initialValue = 101, allocationSize = 1, sequenceName = "stocks_seq")
	@GeneratedValue(generator = "seq")
	private int id;
	private String name;
	private double price;
	@NotNull // validation for quantity
	@Min(value = 1, message = "Quantity should not be less than 1") // minimum value is 1
	private int quantity;
	private double amount;
	private double brokerage;

	// Setters and getters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(double brokerage) {
		this.brokerage = brokerage;
	}

	// To string is used or done
	@Override
	public String toString() {
		return "Stock [id=" + id + ", name=" + name + ", price=" + price + ", quantity=" + quantity + ", amount="
				+ amount + ", brokerage=" + brokerage + "]";
	}
}
