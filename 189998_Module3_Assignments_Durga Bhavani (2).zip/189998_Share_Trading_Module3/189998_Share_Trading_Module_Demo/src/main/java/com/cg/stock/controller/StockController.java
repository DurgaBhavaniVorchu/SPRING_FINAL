package com.cg.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.stock.bean.Stock;
import com.cg.stock.exception.StockException;
import com.cg.stock.service.StockService;

//used to create RESTful web services
@RestController
public class StockController {
	// used to autowire bean on the setter method
	@Autowired
	private StockService stockService;

	// It is a composed annotation that acts as a shortcut for RequestMapping
	@PostMapping("/stocks")
	public List<Stock> addStock(@RequestBody Stock stock) throws StockException {
		return stockService.addStock(stock);

	}

	// Annotation for mapping HTTP PUT requests onto specific handler methods
	@PutMapping("/stocks/update")
	public List<Stock> updateStock(@RequestBody Stock stock) throws StockException {

		return stockService.updateStock(stock);

	}

	// used for mapping web requests to particular handler classes or handler
	// methods
	@RequestMapping("/stocks")
	public List<Stock> getStocks() throws StockException {
		return stockService.getAllStocks(); // service method is called

	}

	// delete annotation is used
	@DeleteMapping("/stocks/{id}")
	public List<Stock> deleteStock(@PathVariable int id) throws StockException { // method is implementing
		return stockService.deleteStock(id); // service method is called
	}

	// get annotation is used
	@GetMapping("/stocks/{id}")
	public Stock getStockById(@PathVariable int id) throws StockException { // method is implementing

		return stockService.getStockById(id); // service method is called

	}

	// handling exceptions in specific handler classes and/or handler methods
	@ExceptionHandler(StockException.class)
	public ResponseEntity<String> handleError(Exception ex) {
		return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);

	}
}
