package com.cg.stock.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.stock.bean.Stock;
import com.cg.stock.dao.StockRepo;
import com.cg.stock.exception.StockException;

//Service method is used
@Service
@Transactional // to begin and commit
public class StockServiceImpl implements StockService { // StockServiceImpl class implements interface StockService
	@Autowired
	StockRepo stockRepo; // indirect object creation

	int idnumber;

	@Override
	public List<Stock> addStock(Stock stock) throws StockException {
		double brokerage;
		double amount = stock.getPrice() * stock.getQuantity();
		if (stockRepo.existsById(stock.getId())) {

			throw new StockException("Stock with id " + stock.getId() + " already exists");
		} else {

			if (stock.getQuantity() > 100) // if statement is executing
			{
				brokerage = ((0.3) / 100) * amount;
			} else {
				brokerage = ((0.5) / 100) * amount;
			}
		}
		/* data is setting or adding in db */
		stock.setBrokerage(brokerage);
		stock.setAmount(amount);
		stockRepo.save(stock); // data is saved in database
		return getAllStocks();
	}

	@Override
	public List<Stock> updateStock(Stock stock) throws StockException {
		double brokerage;
		if (stockRepo.existsById(stock.getId())) {
			double amount = stock.getPrice() * stock.getQuantity();
			if (stock.getQuantity() > 100) // if statement is executing
			{
				brokerage = ((0.3) / 100) * amount;
			} else {
				brokerage = ((0.5) / 100) * amount;
			} /* data is setting or adding in db */
			stock.setBrokerage(brokerage);
			stock.setAmount(amount);
			stockRepo.save(stock);
			return getAllStocks();
		}
		throw new StockException("Stock with id " + stock.getId() + " doesnot exits");
	}

	@Override
	public List<Stock> getAllStocks() throws StockException {
		try {
			return stockRepo.findAll();
		} catch (Exception e) {

			throw new StockException(e.getMessage());
		}
	}

	@Override
	public List<Stock> deleteStock(int id) throws StockException {
		if (!stockRepo.existsById(id)) {
			throw new StockException("Stock with id" + id + " does not exits");
		}
		stockRepo.deleteById(id);
		return getAllStocks();
	}

	@Override
	public Stock getStockById(int id) throws StockException {
		if (!stockRepo.existsById(id)) {
			throw new StockException("Stock with Id " + id + " does not exist");
		}
		return stockRepo.findById(id).get();
	}

}
