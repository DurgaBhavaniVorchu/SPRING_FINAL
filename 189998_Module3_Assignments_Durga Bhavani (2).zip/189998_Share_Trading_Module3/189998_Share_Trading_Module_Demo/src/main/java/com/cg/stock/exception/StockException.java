package com.cg.stock.exception;

//User defined Exception class
public class StockException extends Exception {
	// default constructor
	public StockException() {
		super();
	}

	// parameterized constructor
	public StockException(String msg) {
		super(msg);
	}
}
