package com.cg.capstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.capstore.entity.Categories;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.exception.BussinessAnalysisException;
@Service
public interface IMerchantService {
	List<Merchant> getAllMerchants() throws BussinessAnalysisException;
}
