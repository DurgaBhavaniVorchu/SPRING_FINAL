package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICategoriesDao;
import com.cg.capstore.entity.Categories;
import com.cg.capstore.exception.BussinessAnalysisException;


@Service
@Transactional
public class CategoriesService implements ICategoriesService{

	@Autowired
	private ICategoriesDao categoryDao;
	@Override
	public List<Categories> getAllCategories() throws BussinessAnalysisException{
		try {
			return categoryDao.findAll();
		} catch (Exception e) {
			throw new BussinessAnalysisException(e.getMessage());
		}
	}

	
}
