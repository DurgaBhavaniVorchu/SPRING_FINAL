package com.cg.capstore.exception;

public class BussinessAnalysisException extends Exception{
	public BussinessAnalysisException(){
		super();
	}
	
	public BussinessAnalysisException(String message) {
		super(message);
	}
}
