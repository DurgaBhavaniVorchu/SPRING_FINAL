package com.cg.capstore.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.capstore.exception.BussinessAnalysisException;


//This annotation to handle exceptions across the whole application
@ControllerAdvice
public class GlobalErrorHandler {

	// handling exceptions in specific handler classes and/or handler methods
	@ExceptionHandler({ BussinessAnalysisException.class, Exception.class })
	public ResponseEntity<String> handleError(Exception ex) {
		if (ex.getMessage().equals(
				"Could not commit JPA transaction; nested exception is javax.persistence.RollbackException: Error while committing the transaction")) {
			String message = "Failed";
			return new ResponseEntity<String>(message, HttpStatus.CONFLICT);
		}
		return new ResponseEntity<String>(ex.getMessage(), HttpStatus.CONFLICT);
	}
}
