package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.capstore.entity.Categories;
import com.cg.capstore.entity.Merchant;

@Repository
public interface IMerchantDao extends JpaRepository<Merchant, Integer> {

}
