package com.cg.capstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.capstore.entity.Categories;
import com.cg.capstore.exception.BussinessAnalysisException;


@Service
public interface ICategoriesService {

	List<Categories> getAllCategories() throws BussinessAnalysisException;
}
