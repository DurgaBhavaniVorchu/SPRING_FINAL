package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICategoriesDao;
import com.cg.capstore.dao.IMerchantDao;
import com.cg.capstore.entity.Categories;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.exception.BussinessAnalysisException;
@Service
@Transactional
public class MerchantService implements IMerchantService{
	@Autowired
	private IMerchantDao merchantDao;
	
	@Override
	public List<Merchant> getAllMerchants() throws BussinessAnalysisException{
		try {
			return merchantDao.findAll();
		} catch (Exception e) {
			throw new BussinessAnalysisException(e.getMessage());
		}
	}
}
