package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.entity.Categories;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.exception.BussinessAnalysisException;
import com.cg.capstore.service.ICategoriesService;
import com.cg.capstore.service.IMerchantService;


@RestController
//@CrossOrigin("*")
@RequestMapping("/api/v1")
@CrossOrigin(origins="http://localhost:4200")

public class AdminController {
	@Autowired
	ICategoriesService categoriesService;
	@Autowired
	IMerchantService merchantService;
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/categories")
	public List<Categories> getAllCategories() throws BussinessAnalysisException {
		return categoriesService.getAllCategories();
	}
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/merchant")
	public List<Merchant> getAllMerchants() throws BussinessAnalysisException {
		return merchantService.getAllMerchants();
	}
	
	@ExceptionHandler(BussinessAnalysisException.class)
	public ResponseEntity<String> handleError(Exception ex) {
		return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);

	}
}
